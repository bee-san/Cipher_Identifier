//! Models module
//!
//! This module contains data structures used throughout the application.

pub mod cipher_type;